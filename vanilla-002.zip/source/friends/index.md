---
layout: friends # 必须
title: friends
date: 2022-07-29 00:13:33
type: categories
# comments: false
---

这里写上友链上方的内容

<!-- more 上方的上下必须空行，否则报错 -->

这里可以写友链页面下方的文字备注，例如自己的友链规范、示例等。