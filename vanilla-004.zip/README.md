# 我的个人博客源码

克隆仓库代码
```
git clone https://github.com/txw1314/valinilla.git
```

### 安装依赖
```
npm install
```

### 本地运行博客
```
hexo clean && hexo g && hexo s

```

### 部署博客
```
hexo clean && hexo g && hexo d
```

### 新建页面
```
hexo new <文章名称>
```

### 8.2更新内容
- 归档歌曲标志
- 暗夜模式
- 评论更改
- 评论教程
- 头图封面
- 首页分页
