---
title: fariy-001
date: 2022-07-28 20:18:46
tags: fariy
categories: 壁纸
type: categories
## 文章头图设置
index_img: https://img2.baidu.com/it/u=4041237652,3455375873&fm=253&fmt=auto&app=138&f=JPEG?w=889&h=500
banner_img: https://img2.baidu.com/it/u=4041237652,3455375873&fm=253&fmt=auto&app=138&f=JPEG?w=889&h=500
headimg: https://img2.baidu.com/it/u=4041237652,3455375873&fm=253&fmt=auto&app=138&f=JPEG?w=889&h=500
img: https://img2.baidu.com/it/u=4041237652,3455375873&fm=253&fmt=auto&app=138&f=JPEG?w=889&h=500
cover: https://img2.baidu.com/it/u=4041237652,3455375873&fm=253&fmt=auto&app=138&f=JPEG?w=889&h=500
music:
  server: netease
  type: song
  id: 557581284
---
# 精美壁纸

![太空人](https://gimg2.baidu.com/image_search/src=http%3A%2F%2Fimg.jj20.com%2Fup%2Fallimg%2F4k%2Fs%2F01%2F210924143942AV-0-lp.jpg&refer=http%3A%2F%2Fimg.jj20.com&app=2002&size=f9999,10000&q=a80&n=0&g=0n&fmt=auto?sec=1661603132&t=1f048fc0b2d6b6052d8fa10a0c0c2a66)

![2022](https://img2.baidu.com/it/u=4041237652,3455375873&fm=253&fmt=auto&app=138&f=JPEG?w=889&h=500)

![山脉](https://img2.baidu.com/it/u=3912953751,2897910146&fm=253&fmt=auto&app=138&f=JPEG?w=889&h=500)

![公路](https://img2.baidu.com/it/u=1830973642,518401107&fm=253&fmt=auto&app=120&f=JPEG?w=889&h=500)

![跑车](https://img0.baidu.com/it/u=3307765823,1934426814&fm=253&fmt=auto&app=120&f=JPEG?w=889&h=500)

![灯塔](https://img1.baidu.com/it/u=2688422801,1696196797&fm=253&fmt=auto&app=138&f=JPEG?w=889&h=500)

![灯塔](https://img1.baidu.com/it/u=674567296,600896811&fm=253&fmt=auto&app=138&f=JPEG?w=889&h=500)

![颠倒时空](https://img0.baidu.com/it/u=3440708810,3442918705&fm=253&fmt=auto&app=138&f=JPEG?w=889&h=500)

![大寒](https://img1.baidu.com/it/u=872134080,2905781283&fm=253&fmt=auto&app=120&f=JPEG?w=889&h=500)

![粉色](https://img1.baidu.com/it/u=1511941592,1801635068&fm=253&fmt=auto&app=138&f=JPEG?w=889&h=500)

![珍珠](https://img1.baidu.com/it/u=2097372425,2422966379&fm=253&fmt=auto&app=120&f=JPEG?w=889&h=500)

![水泡](https://img0.baidu.com/it/u=1656587050,3930583270&fm=253&fmt=auto&app=138&f=JPEG?w=889&h=500)

![花草日历](https://img0.baidu.com/it/u=3421760785,1781416260&fm=253&fmt=auto&app=138&f=JPEG?w=889&h=500)

![船舰](https://img1.baidu.com/it/u=2643860120,1785013409&fm=253&fmt=auto&app=138&f=JPEG?w=889&h=500)

![流体](https://img2.baidu.com/it/u=3547004283,1966895282&fm=253&fmt=auto&app=138&f=JPEG?w=889&h=500)

![跑车](https://img1.baidu.com/it/u=1692648092,2998825096&fm=253&fmt=auto&app=138&f=JPEG?w=889&h=500)

![鹤](https://img2.baidu.com/it/u=2899977724,4160359019&fm=253&fmt=auto&app=138&f=JPEG?w=889&h=500)

![2022](https://img1.baidu.com/it/u=4094397582,1558263522&fm=253&fmt=auto&app=138&f=JPEG?w=889&h=500)

