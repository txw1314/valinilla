---
title: typora破解版安装
tags: 
  - typora
  - 破解版
categories: typora
type: categories
description: typora破解版安装
date: 2022-07-30 23:56:45
## 文章头图设置
index_img: https://img1.baidu.com/it/u=1511941592,1801635068&fm=253&fmt=auto&app=138&f=JPEG?w=889&h=500
banner_img: https://img1.baidu.com/it/u=1511941592,1801635068&fm=253&fmt=auto&app=138&f=JPEG?w=889&h=500
headimg: https://img1.baidu.com/it/u=1511941592,1801635068&fm=253&fmt=auto&app=138&f=JPEG?w=889&h=500
img: https://img1.baidu.com/it/u=1511941592,1801635068&fm=253&fmt=auto&app=138&f=JPEG?w=889&h=500
cover: https://img1.baidu.com/it/u=1511941592,1801635068&fm=253&fmt=auto&app=138&f=JPEG?w=889&h=500
music:
  server: netease
  type: song
  id: 1940308932
---

typora收费，对程序猿来说是不可能的，我只会白嫖，今天在小破站看到一个破解版的typora的安装，分享给大家。

> 我把软件和破解文件放到了自己的阿里云盘分享给大家，附上链接：「typora1.3.8」等文件 https://www.aliyundrive.com/s/WLHNPidNYrL 

# 1.1 下载完之后，选择安装包正常安装即可

![](https://cdn.jsdelivr.net/gh/txw1314/blog-img@main/img/image-20220731000444283.png)

# 1.2 打开破解插件，复制文件。桌面typora图标右键打开文件所在位置，粘贴复制的破解文件，替换即可，此时已经破解完成了

打开typora，点击帮助—我的许可证，将看到破解好的typora，是不是特别简单，我也是惊艳到了。

![](https://cdn.jsdelivr.net/gh/txw1314/blog-img@main/img/image-20220731000852072.png)
