# 我的个人博客源码

克隆仓库代码
```
git clone https://github.com/txw1314/valinilla.git
```

### 安装依赖
```
npm install
```

### 本地运行博客
```
hexo clean && hexo g && hexo s

```

### 部署博客
```
hexo clean && hexo g && hexo d
```

### 新建页面
```
hexo new <文章名称>
```
